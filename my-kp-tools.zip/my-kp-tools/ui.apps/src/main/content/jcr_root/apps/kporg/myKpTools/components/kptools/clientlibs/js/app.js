function toCSV(json) {
  json = Object.values(json);
  var csv = "";
  var keys = (json[0] && Object.keys(json[0])) || [];
  csv += keys.join(',') + '\n';
  for (var line of json) {
    csv += keys.map(key => line[key]).join(',') + '\n';
  }
  return csv;
}

$(document).ready(function() {
	console.log('in tools listing js');
    
    $('.no-input-available').hide();
	$.ajax({
        url: "/bin/kp/getToolsSearchResults",
        type: 'GET',
        dataType: 'json',
        data: {},
        success: function(data) {
            if(data.length === 0) {
                alert("No results for the search term. Try another one!");
            } 
            updateListingData(data);
        }
        	
    });
    
    $('.tools-search').on('click', function(event) {
        
        var searchIput = $("#search-term").val();
        if(searchIput == null || searchIput == undefined || searchIput.trim() == '') {
            $('.no-input-available').show();
        } else 
            $('.no-input-available').hide();
        
        $.ajax({
        url: "/bin/kp/getToolsSearchResults",
        type: 'GET',
        dataType: 'json',
        data: {
            'searchTerm': searchIput
        },
        success: function(data) {
            if(data.length === 0) {
                alert("No results for the search term. Try another one!");
            } 
            updateListingData(data);
        }
        	
    });
            
	  console.log("search input click"+searchIput);
  });
    
    function updateListingData(data) {
        var toolELe = ""
        	for(var i = 0; i < data.length; i++) {
        		var contentsEle = data[i].contents;
        		toolELe += "<h3><a target='_blank' href='"+data[i].url+"'>"+contentsEle.title+"</a></h3>";
        		toolELe += "<p>"+contentsEle.snippet+"</p>";
        		toolELe += "<p><b> Legal Entity: </b>"+contentsEle["legal-entity"];
        		toolELe += "<b>   Region: </b>"+contentsEle.region;
        		toolELe += "<b>   Business Function: </b> "+contentsEle["business-function"];
        		toolELe += "<b>   Tool Function: </b> "+contentsEle["tool-function"]+"</p>";
        		toolELe += "<p><b> Active Start: </b>"+contentsEle["start-date"]+"<b>    Active End: </b>"+contentsEle["end-date"]+"</p>";
        		toolELe += "<p><b> Tool ID: </b>"+contentsEle.id+"<b>    Owner: </b>"+contentsEle["owner-name"]+"    "+contentsEle["owner-id"]+"</p>";
        		
        	}
        	$(".tools-section").html(toolELe);
        	}
    
    
});
