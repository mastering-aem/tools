package org.kp.aem.mykptools.core.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.security.user.UserPropertiesService;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Component(service = Servlet.class, name = "org.kp.aem.kporgcms.core.servlets.GetToolsSearchResultsServlet", property = {
		"sling.servlet.paths=/bin/kp/getToolsSearchResults", "sling.servlet.methods=get",
		"sling.servlet.extensions=html" })

public class GetToolsSearchResultsServlet extends SlingAllMethodsServlet {
	static final long serialVersionUID = 1L;


	@Reference
	private ResourceResolverFactory resourceResolverFactory;

	@Reference
	private UserPropertiesService ups;
	

	Logger log = LoggerFactory.getLogger(GetToolsSearchResultsServlet.class);

	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter writer = response.getWriter();
		String searchTerm = request.getParameter("searchTerm");
		String url = "https://search-qa.kp.org/vivisimo/cgi-bin/query-meta?query=&v:project=mykp-tools-project";
		if(searchTerm != null && !searchTerm.trim().isEmpty()) {
			url = url.replace("query=", "query="+searchTerm);
		}
		
		try {
			JsonArray jsonResponse = getSearchResponse(url);
			//JsonArray jsonResponse = getSearchResponseFromJSONFILE() ;
			if (jsonResponse != null) {
				response.setStatus(HttpServletResponse.SC_OK);
				response.getWriter().print(jsonResponse);
				response.getWriter().flush();
			} else {
				response.setStatus(HttpServletResponse.SC_OK);
				JsonObject noResultsFoundResponse = new JsonObject();
				noResultsFoundResponse.addProperty("error", "No results found!");
				response.getWriter().print(jsonResponse);
				response.getWriter().flush();
			}
			
		} catch (Exception e) {
			response.setContentType("text/plain; charset=UTF-8");
			response.setStatus(HttpServletResponse.SC_BAD_GATEWAY);
			writer = response.getWriter();
			writer.println("Exception caught in GetContentPathApproversServlet.doGet with the following message: "
					+ e.getMessage());
			log.error("Exception caught in GetContentPathApproversServlet.doGet with the following message: "
					+ e.getMessage());
		}

	}
	
	private JsonArray getSearchResponse(String urlString) {
		try {
			URL url = new URL(urlString);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();

			connection.setRequestMethod("GET");
			connection.setRequestProperty("User-Agent", "Mozilla/5.0");

			InputStream content = (InputStream) connection.getInputStream();
			BufferedReader in = new BufferedReader(new InputStreamReader(content));
			String line;
			String total = "";
			while ((line = in.readLine()) != null) {
				total += line;
			}
			
			JsonObject jsonResponse = new JsonParser().parse(total).getAsJsonObject();

			if(jsonResponse != null) {
				JsonObject listElement = jsonResponse.getAsJsonObject("list");
				if(listElement != null) {
					JsonArray documentArray = listElement.getAsJsonArray("document");
					return documentArray;
				}
	        }
			return null;
		} catch (Exception e) {
			log.error("Error occurred while calling the url : "+urlString, e);
			return null;
		}
		
	}
	
	private JsonArray getSearchResponseFromJSONFILE() {

	    StringBuilder contentBuilder = new StringBuilder();
	    
	    try (Stream<String> stream = Files.lines( Paths.get("/Users/sai/Development/AEM_Projects/kporg-cms/core/src/main/java/org/kp/aem/kporgcms/core/servlets/SampleSearchResults.json"), StandardCharsets.UTF_8)) 
	    {
	        stream.forEach(s -> contentBuilder.append(s).append("\n"));
	        String jsonContent = contentBuilder.toString();
		    
	        JsonObject jsonResponse = new JsonParser().parse(jsonContent).getAsJsonObject();
	        if(jsonResponse != null) {
	        	JsonArray jsonArray = jsonResponse.getAsJsonArray("document");
	        	return jsonArray;
	        }
	        return null;	
	    }
	    catch (Exception e) 
	    {
	    	log.error("Error occurred while reading json file : ", e);
	    	return null;
	    }
		
	}


}